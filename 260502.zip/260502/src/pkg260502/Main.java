/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg260502;

import javax.swing.JOptionPane;

/**
 *
 * @author juliana.plima10
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* TODO code application logic here
        int valor = 5;
        String valor2 = "10";
        int valor3 = 0;
        int[]numeros ={50,30,40};
        System.out.println(numeros[10]);
        System.out.println(valor + valor2);
        System.out.println(valor/valor3);
        */
        
        /*int valor = 5;
        int valor2 = 0;
        
        try{
            
            int resultado = valor/valor2;
            
            System.out.println(" o resultado é" + resultado);
            
        }catch(ArithmeticException e){
            
            System.out.println("divisão por zero");
            
        }
    }
}
*/
        
   String idadeTextos = JOptionPane.showImputDialog("Digite sua idade (apenas numeros):");
   try {
       
   int idade = Integer.parseInt(idadeTexto);
   
   JOptionPane.showMessageDialog(null, "Sua idade é: " + idade + "anos.");
   
   } catch({NumberFormatException e) {
       
   JOptionPane.showMessageDialog(null,
           
            "Erro de Formatos: Por favor, digite apenas números inteiros válidos",
            "Erro de Entrada", JOptionPane.ERROR_MESSAGE);
           
   }
   System.out.println("Processos de idade finalizado.");
   

}
    
   
    
    
    
    
    
    

